#ifndef MAPPING_H
#define MAPPING_H

/*
  MAPPING JALUR ROBOT - versi SCRIPT per persimpangan
  ====================================================================
  File ini KHUSUS buat atur apa yang robot lakuin di tiap persimpangan,
  biar gampang diedit tanpa bongkar file utama.

  CARA PAKAI:
  Edit fungsi executeMapStep() di bawah. Tiap "case N:" = persimpangan
  ke-N (N=1 simpang pertama, N=2 simpang kedua, dst - sama kayak
  intersectionCount). Isi tiap case BEBAS, gabungin primitive di bawah
  sesuai urutan yang lu mau.

  WAJIB set actionDone = true kalau case itu mau AMBIL ALIH (skip
  logic default LURUS buat simpang ini). Kalau case kosong / nomor
  simpangnya belum di-map sama sekali, actionDone tetap false ->
  robot default LURUS (lanjut ngikutin PD normal, behavior lama,
  ga ada yang berubah).

  PRIMITIVE YANG TERSEDIA (implementasinya di file utama .ino):
    turnLeft()            - pivot belok kiri 90 derajat (LED cyan lari kiri)
    turnRight()            - pivot belok kanan 90 derajat (LED pink lari kanan)
    turnAround()            - putar balik 180 derajat (LED ungu nyebar)
    maju(ms)                - jalan lurus BASE_SPEED selama ms (default MAJU_MS)
    mundur(ms)               - jalan MUNDUR selama ms (default MUNDUR_MS), LED amber blink
    stopSesaat(ms)            - motor berhenti SEBENTAR (default STOP_SESAAT_MS),
                                 TAPI robot TETAP lanjut ke simpang berikutnya -
                                 BEDA sama selesaiRute() yang tamatin seluruh rute!
    resetLineFollowing()      - reset lastError/lastErrorSign PD, dipanggil abis
                                 manuver ganjil (kayak turnAround) biar PD ga "kaget"
    ambilKotak()              - placeholder servo ambil barang (servo BELUM
                                 diintegrasi, masih di tesServo.ino terpisah)
    lepasKotak()              - placeholder servo lepas barang (belum diintegrasi)
    selesaiRute()              - tandain SELURUH rute kelar -> robot stop total,
                                 LED hijau blink (state FINISH), lalu OTOMATIS
                                 balik ke IDLE (tinggal pencet START lagi buat
                                 run berikutnya - TIDAK mengunci/hang selamanya)

  CONTOH DI BAWAH (silakan diganti sesuai jalur arena beneran):
    simpang 1 -> belok kiri
    simpang 2 -> stop sesaat, ambil kotak, puter balik, reset PD
    simpang 3 -> (kosong, LURUS)
    simpang 4 -> stop sesaat, lepas kotak, puter balik
    simpang 5 -> belok kanan
    simpang 6 -> maju dikit, lalu SELESAI (auto balik ke IDLE)
  ====================================================================
*/

enum TurnAction { ACT_LURUS, ACT_KIRI, ACT_KANAN, ACT_PUTAR, ACT_BERHENTI };

// ---- Tuning maneuver (kecepatan & durasi) - WAJIB dikalibrasi manual di
//      lapangan, beda arena/beban robot = beda waktu yang pas ----
const int           TURN_SPEED     = 200; // kecepatan pivot belok/putar (0-255)
const unsigned long TURN_KIRI_MS   = 350; // durasi pivot kiri  (~90 derajat)
const unsigned long TURN_KANAN_MS  = 350; // durasi pivot kanan (~90 derajat)
const unsigned long TURN_PUTAR_MS  = 600; // durasi u-turn      (~180 derajat)
const unsigned long MAJU_MS        = 300; // durasi default maju()
const unsigned long MUNDUR_MS      = 300; // durasi default mundur()
const unsigned long STOP_SESAAT_MS = 1000; // durasi default stopSesaat()

// ------------------------ EDIT DI SINI ------------------------
void executeMapStep(unsigned int simpangKe, bool &actionDone) {
  switch (simpangKe) {
    case 1:
      turnLeft();
      actionDone = true;
      break;

    case 2:
      stopSesaat();
      ambilKotak();
      turnAround();
      resetLineFollowing();
      actionDone = true;
      break;

    case 3:
      actionDone = true; // sengaja kosong = LURUS eksplisit (contoh)
      break;

    case 4:
      stopSesaat();
      lepasKotak();
      turnAround();
      actionDone = true;
      break;

    case 5:
      turnRight();
      actionDone = true;
      break;

    case 6:
      maju();
      selesaiRute();
      actionDone = true;
      break;

    default:
      break; // actionDone tetap false -> LURUS normal
  }
}
// ----------------------------------------------------------------

// ====================================================================
// CATATAN RENCANA (BELUM DIIMPLEMENTASI - cuma buat persiapan):
// Ke depan mau ada beberapa PROFIL mapping (misal executeMapStep_A,
// executeMapStep_B, executeMapStep_C), masing-masing skenario/jalur
// beda, dan robot bisa milih profil mana yang dipakai (misal lewat
// tombol tambahan, dip-switch, atau warna kotak yang kedeteksi) sebelum
// mulai jalan. Versi sekarang masih 1 skenario tunggal dulu, sengaja
// disederhanain biar gampang dites & diedit.
// ====================================================================

#endif
